import { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Plus, Minus, ShoppingBag, MessageCircle, Smartphone, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Link, useNavigate } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface CartItem {
  id: string;
  quantity: number;
  product_id: string;
  products: {
    name: string;
    price: number;
    image_url: string | null;
    store_id: string | null;
    stores: {
      id: string;
      name: string;
      slug: string | null;
      whatsapp_phone: string | null;
      mpesa_enabled: boolean | null;
      mpesa_status: string | null;
    } | null;
  } | null;
}

interface StoreGroup {
  storeId: string;
  storeName: string;
  storeSlug: string | null;
  whatsappPhone: string | null;
  mpesaEnabled: boolean;
  mpesaApproved: boolean;
  items: CartItem[];
  subtotal: number;
}

const Cart = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // M-Pesa payment state
  const [mpesaDialogOpen, setMpesaDialogOpen] = useState(false);
  const [selectedStore, setSelectedStore] = useState<StoreGroup | null>(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'pending' | 'success' | 'failed'>('idle');
  const [transactionRef, setTransactionRef] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      fetchCartItems();
    } else {
      setLoading(false);
    }
  }, [user]);

  // Poll for payment status
  useEffect(() => {
    if (paymentStatus !== 'pending' || !transactionRef || !selectedStore) return;

    const pollInterval = setInterval(async () => {
      try {
        const { data, error } = await supabase.functions.invoke('mpesa-stk-push', {
          body: {
            action: 'check-status',
            transactionReference: transactionRef,
            storeId: selectedStore.storeId
          }
        });

        if (error) {
          console.error('Status check error:', error);
          return;
        }

        const status = data?.data?.response?.Status?.toLowerCase();
        if (status === 'success') {
          setPaymentStatus('success');
          clearInterval(pollInterval);
          toast({
            title: "Payment Successful!",
            description: `Receipt: ${data?.data?.response?.MpesaReceiptNumber}`,
          });
        } else if (status === 'failed') {
          setPaymentStatus('failed');
          clearInterval(pollInterval);
          toast({
            title: "Payment Failed",
            description: data?.data?.response?.ResultDesc || "Payment was not completed",
            variant: "destructive",
          });
        }
      } catch (err) {
        console.error('Polling error:', err);
      }
    }, 5000);

    // Stop polling after 2.5 minutes
    const timeout = setTimeout(() => {
      clearInterval(pollInterval);
      if (paymentStatus === 'pending') {
        setPaymentStatus('failed');
        toast({
          title: "Payment Timeout",
          description: "Payment verification timed out. Please check your M-Pesa messages.",
          variant: "destructive",
        });
      }
    }, 150000);

    return () => {
      clearInterval(pollInterval);
      clearTimeout(timeout);
    };
  }, [paymentStatus, transactionRef, selectedStore]);

  const fetchCartItems = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("cart")
        .select(`
          id,
          quantity,
          product_id,
          products!cart_product_id_fkey (
            name,
            price,
            image_url,
            store_id,
            stores!products_store_id_fkey (id, name, slug, whatsapp_phone, mpesa_enabled, mpesa_status)
          )
        `)
        .eq("user_id", user.id);

      if (error) throw error;
      setCartItems(data || []);
    } catch (error) {
      console.error("Error fetching cart items:", error);
      toast({
        title: "Error",
        description: "Failed to load cart items",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Group cart items by store
  const groupItemsByStore = (): StoreGroup[] => {
    const storeMap = new Map<string, StoreGroup>();

    cartItems.forEach((item) => {
      const storeId = item.products?.stores?.id || "unknown";
      const storeName = item.products?.stores?.name || "Unknown Store";
      const storeSlug = item.products?.stores?.slug || null;
      const whatsappPhone = item.products?.stores?.whatsapp_phone || null;
      const mpesaEnabled = item.products?.stores?.mpesa_enabled || false;
      const mpesaApproved = item.products?.stores?.mpesa_status === 'approved';

      if (!storeMap.has(storeId)) {
        storeMap.set(storeId, {
          storeId,
          storeName,
          storeSlug,
          whatsappPhone,
          mpesaEnabled,
          mpesaApproved,
          items: [],
          subtotal: 0,
        });
      }

      const group = storeMap.get(storeId)!;
      group.items.push(item);
      group.subtotal += (item.products?.price || 0) * item.quantity;
    });

    return Array.from(storeMap.values());
  };

  async function updateQuantity(itemId: string, newQuantity: number) {
    if (newQuantity <= 0) {
      await removeItem(itemId);
      return;
    }

    try {
      const { error } = await supabase
        .from("cart")
        .update({ quantity: newQuantity })
        .eq("id", itemId);

      if (error) throw error;
      
      setCartItems(items =>
        items.map(item =>
          item.id === itemId ? { ...item, quantity: newQuantity } : item
        )
      );
    } catch (error) {
      console.error("Error updating quantity:", error);
      toast({
        title: "Error",
        description: "Failed to update quantity",
        variant: "destructive",
      });
    }
  }

  async function removeItem(itemId: string) {
    try {
      const { error } = await supabase
        .from("cart")
        .delete()
        .eq("id", itemId);

      if (error) throw error;
      
      setCartItems(items => items.filter(item => item.id !== itemId));
      
      toast({
        title: "Success",
        description: "Item removed from cart",
      });
    } catch (error) {
      console.error("Error removing item:", error);
      toast({
        title: "Error",
        description: "Failed to remove item",
        variant: "destructive",
      });
    }
  }

  function getTotalPrice() {
    return cartItems.reduce((total, item) => {
      return total + (item.products?.price || 0) * item.quantity;
    }, 0);
  }

  const handleOrderOnWhatsApp = (storeGroup: StoreGroup) => {
    if (!storeGroup.whatsappPhone) {
      toast({
        title: "WhatsApp not available",
        description: "This store hasn't set up WhatsApp ordering yet.",
        variant: "destructive",
      });
      return;
    }

    // Build order message
    const itemsList = storeGroup.items
      .map(item => `• ${item.products?.name} x${item.quantity} - KSh ${((item.products?.price || 0) * item.quantity).toLocaleString()}`)
      .join('\n');
    
    const message = `Hello! I'd like to order from ${storeGroup.storeName}:\n\n${itemsList}\n\nTotal: KSh ${storeGroup.subtotal.toLocaleString()}`;
    
    const whatsappUrl = `https://wa.me/${storeGroup.whatsappPhone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handlePayViaMpesa = (storeGroup: StoreGroup) => {
    if (!storeGroup.mpesaEnabled || !storeGroup.mpesaApproved) {
      toast({
        title: "M-Pesa Not Available",
        description: "This store hasn't activated M-Pesa payments yet.",
        variant: "destructive",
      });
      return;
    }

    setSelectedStore(storeGroup);
    setPhoneNumber("");
    setPaymentStatus('idle');
    setTransactionRef(null);
    setMpesaDialogOpen(true);
  };

  const initiatePayment = async () => {
    if (!selectedStore || !phoneNumber) return;

    // Validate phone number
    const cleanPhone = phoneNumber.replace(/\s+/g, '');
    if (!/^(254|0|\+254)?[17]\d{8}$/.test(cleanPhone)) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid Safaricom phone number",
        variant: "destructive",
      });
      return;
    }

    setPaymentLoading(true);
    setPaymentStatus('idle');

    try {
      const { data, error } = await supabase.functions.invoke('mpesa-stk-push', {
        body: {
          action: 'initiate',
          storeId: selectedStore.storeId,
          phoneNumber: cleanPhone,
          amount: selectedStore.subtotal,
          metadata: {
            items: selectedStore.items.map(i => ({
              name: i.products?.name,
              quantity: i.quantity,
              price: i.products?.price
            }))
          }
        }
      });

      if (error) throw error;

      if (data?.success) {
        setTransactionRef(data.data.transactionReference);
        setPaymentStatus('pending');
        toast({
          title: "STK Push Sent",
          description: "Please check your phone and enter your M-Pesa PIN",
        });
      } else {
        throw new Error(data?.error || 'Failed to initiate payment');
      }
    } catch (error: any) {
      console.error('Payment initiation error:', error);
      setPaymentStatus('failed');
      toast({
        title: "Payment Failed",
        description: error.message || "Failed to initiate M-Pesa payment",
        variant: "destructive",
      });
    } finally {
      setPaymentLoading(false);
    }
  };

  const handleStoreClick = (storeSlug: string | null) => {
    if (storeSlug) {
      navigate(`/store/${storeSlug}`);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Please Login</h1>
            <p className="text-gray-600 mb-6">You need to login to view your cart</p>
            <Link to="/auth">
              <Button className="bg-orange-600 hover:bg-orange-700">Login</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-600"></div>
          </div>
        </div>
      </div>
    );
  }

  const storeGroups = groupItemsByStore();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Shopping Cart</h1>

        {cartItems.length === 0 ? (
          <div className="text-center py-12">
            <ShoppingBag size={64} className="mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-600 mb-2">Your cart is empty</h2>
            <p className="text-gray-500 mb-6">Start shopping to add items to your cart</p>
            <Link to="/marketplace">
              <Button className="bg-orange-600 hover:bg-orange-700">
                Continue Shopping
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {storeGroups.map((storeGroup) => (
                <Card key={storeGroup.storeId} className="overflow-hidden">
                  {/* Store Header with Actions */}
                  <CardHeader className="bg-orange-50 border-b">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <CardTitle 
                        className="text-lg cursor-pointer hover:text-orange-600 transition-colors"
                        onClick={() => handleStoreClick(storeGroup.storeSlug)}
                      >
                        {storeGroup.storeName}
                      </CardTitle>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex items-center gap-2 border-green-600 text-green-600 hover:bg-green-50"
                          onClick={() => handleOrderOnWhatsApp(storeGroup)}
                        >
                          <MessageCircle size={16} />
                          <span className="hidden sm:inline">Order on WhatsApp</span>
                          <span className="sm:hidden">WhatsApp</span>
                        </Button>
                        <Button
                          size="sm"
                          className={`flex items-center gap-2 text-white ${
                            storeGroup.mpesaEnabled && storeGroup.mpesaApproved
                              ? 'bg-green-600 hover:bg-green-700'
                              : 'bg-gray-400 cursor-not-allowed'
                          }`}
                          onClick={() => handlePayViaMpesa(storeGroup)}
                          disabled={!storeGroup.mpesaEnabled || !storeGroup.mpesaApproved}
                        >
                          <Smartphone size={16} />
                          <span className="hidden sm:inline">Pay via M-Pesa</span>
                          <span className="sm:hidden">M-Pesa</span>
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-2">
                      Subtotal: <span className="font-semibold text-orange-600">KSh {storeGroup.subtotal.toLocaleString()}</span>
                    </p>
                  </CardHeader>

                  {/* Products in this store */}
                  <CardContent className="p-4 space-y-4">
                    {storeGroup.items.map((item) => (
                      <div key={item.id} className="flex items-center space-x-4 p-3 bg-white rounded-lg border">
                        <img
                          src={item.products?.image_url || "/placeholder.svg"}
                          alt={item.products?.name}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-sm sm:text-base truncate">{item.products?.name}</h3>
                          <p className="text-orange-600 font-bold">
                            KSh {item.products?.price?.toLocaleString()}
                          </p>
                        </div>
                        <div className="flex items-center space-x-1 sm:space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          >
                            <Minus size={14} />
                          </Button>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                            className="w-12 text-center text-black h-8 text-sm"
                            min="1"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus size={14} />
                          </Button>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeItem(item.id)}
                          className="text-red-600 hover:text-red-700 h-8 w-8 p-0"
                        >
                          <Trash2 size={18} />
                        </Button>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="lg:col-span-1">
              <Card className="sticky top-4">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Order Summary</h3>
                  <div className="space-y-3 mb-4">
                    {storeGroups.map((group) => (
                      <div key={group.storeId} className="flex justify-between text-sm">
                        <span className="text-gray-600">{group.storeName}</span>
                        <span>KSh {group.subtotal.toLocaleString()}</span>
                      </div>
                    ))}
                    <div className="border-t pt-2">
                      <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span>KSh {getTotalPrice().toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>Shipping</span>
                        <span>Calculated at checkout</span>
                      </div>
                    </div>
                    <div className="border-t pt-2">
                      <div className="flex justify-between font-semibold text-lg">
                        <span>Total</span>
                        <span className="text-orange-600">KSh {getTotalPrice().toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                  <Link to="/checkout">
                    <Button className="w-full bg-orange-600 hover:bg-orange-700">
                      Proceed to Checkout
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      {/* M-Pesa Payment Dialog */}
      <Dialog open={mpesaDialogOpen} onOpenChange={setMpesaDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Smartphone className="text-green-600" size={24} />
              Pay via M-Pesa
            </DialogTitle>
            <DialogDescription>
              Enter your Safaricom phone number to receive the payment prompt
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {selectedStore && (
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-sm text-gray-600">Paying to:</p>
                <p className="font-semibold">{selectedStore.storeName}</p>
                <p className="text-lg font-bold text-green-600">
                  KSh {selectedStore.subtotal.toLocaleString()}
                </p>
              </div>
            )}
            
            {paymentStatus === 'idle' && (
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="e.g., 0712345678 or 254712345678"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Enter your Safaricom M-Pesa number
                </p>
              </div>
            )}
            
            {paymentStatus === 'pending' && (
              <div className="text-center py-4">
                <Loader2 className="h-12 w-12 animate-spin text-green-600 mx-auto mb-4" />
                <p className="font-semibold text-lg">Waiting for payment...</p>
                <p className="text-sm text-gray-600">
                  Please check your phone and enter your M-Pesa PIN
                </p>
              </div>
            )}
            
            {paymentStatus === 'success' && (
              <div className="text-center py-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Smartphone className="text-green-600" size={32} />
                </div>
                <p className="font-semibold text-lg text-green-600">Payment Successful!</p>
                <p className="text-sm text-gray-600">
                  Your order has been placed. Thank you!
                </p>
              </div>
            )}
            
            {paymentStatus === 'failed' && (
              <div className="text-center py-4">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Smartphone className="text-red-600" size={32} />
                </div>
                <p className="font-semibold text-lg text-red-600">Payment Failed</p>
                <p className="text-sm text-gray-600">
                  Please try again or use a different payment method
                </p>
              </div>
            )}
          </div>
          
          <div className="flex gap-2">
            {paymentStatus === 'idle' && (
              <>
                <Button
                  variant="outline"
                  onClick={() => setMpesaDialogOpen(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={initiatePayment}
                  disabled={!phoneNumber || paymentLoading}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  {paymentLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    'Send Payment Request'
                  )}
                </Button>
              </>
            )}
            
            {paymentStatus === 'pending' && (
              <Button
                variant="outline"
                onClick={() => {
                  setPaymentStatus('idle');
                  setTransactionRef(null);
                }}
                className="w-full"
              >
                Cancel & Try Again
              </Button>
            )}
            
            {(paymentStatus === 'success' || paymentStatus === 'failed') && (
              <Button
                onClick={() => {
                  setMpesaDialogOpen(false);
                  if (paymentStatus === 'success') {
                    // Optionally clear cart items for this store
                    fetchCartItems();
                  }
                }}
                className="w-full"
              >
                Close
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Cart;
